import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router';
import {
  ArrowLeft, Check, CheckCircle2, Copy, CreditCard,
  Edit2, Search, Smartphone, Users, X, AlertCircle,
  Clock, Award, ChevronRight, Info, Mail, Tag,
} from 'lucide-react';

// ─── Figma assets ─────────────────────────────────────────────────────────────
import imgBanner   from 'figma:asset/e105b5e610ed3a80a379fd20d3b62ba8ac6e74be.png';
import imgRectangle4  from 'figma:asset/18e0078e781e0d8c3de74aa82ce4588b85c64e1e.png';
import imgRectangle5  from 'figma:asset/c832668ea2483d22124deffdce1f99bb68cbad49.png';
import imgRectangle6  from 'figma:asset/eab11e33b34d5ba97024c67db25c372841debd6d.png';
import imgRectangle7  from 'figma:asset/58075a1fa65e2bf06f14b5b4d6d38df67040cd77.png';
import imgRectangle8  from 'figma:asset/fcc48026d509e55f64b35ef15506a29175bcf128.png';
import imgRectangle9  from 'figma:asset/331e967b4caddafb3c0e7a36025e6167046e0778.png';
import imgRectangle10 from 'figma:asset/593a6a36c62b9ecc7dd1d304b22df376a0f1c15e.png';
import imgSynergy  from 'figma:asset/c1bbbe3578f99a2cce1355514a603fdcb1c8dc52.png';

// ─── Types ────────────────────────────────────────────────────────────────────
type CheckoutStep =
  | 'auth' | 'categories' | 'partners' | 'uniforms'
  | 'review' | 'billing' | 'payment-method' | 'payment-details' | 'success';

interface Category {
  id: string;
  name: string;
  gender: string;
  pricePerAthlete: number;
  spotsLeft: number;
  total: number;
}

interface Partner {
  id: string;
  nickname: string;
  name: string;
  avatar?: string;
  isPrecadastro?: boolean;
  precadastroEmail?: string;
  precadastroCpf?: string;   // NOVO campo obrigatório
  precadastroPhone?: string;
}

interface CheckoutData {
  user: { name: string; email: string } | null;
  selectedCategories: Category[];
  partners: Record<string, Partner | null>;
  uniforms: Record<string, { me: string; partner: string }>;
  billing: { name: string; cpf: string; email: string };
  couponCode: string;
  couponStatus: 'idle' | 'loading' | 'valid' | 'invalid';
  couponDiscount: number;
  // ─ Divisão de pagamento: por categoria (catId → 'full' | 'mine')
  payOptions: Record<string, 'full' | 'mine'>;
  paymentMethod: 'pix' | 'credit_card' | null;
}

// ─── Constants ────────────────────────────────────────────────────────────────
const CATEGORIES: Category[] = [
  { id: 'prof-masc', name: 'Profissional', gender: 'Masculino', pricePerAthlete: 120, spotsLeft: 8,  total: 32 },
  { id: 'prof-fem',  name: 'Profissional', gender: 'Feminino',  pricePerAthlete: 120, spotsLeft: 12, total: 32 },
  { id: 'inic-masc', name: 'Iniciante',    gender: 'Masculino', pricePerAthlete: 80,  spotsLeft: 4,  total: 32 },
  { id: 'inic-fem',  name: 'Iniciante',    gender: 'Feminino',  pricePerAthlete: 80,  spotsLeft: 16, total: 32 },
  { id: 'amad-masc', name: 'Amador',       gender: 'Masculino', pricePerAthlete: 60,  spotsLeft: 0,  total: 32 },
  { id: 'amad-fem',  name: 'Amador',       gender: 'Feminino',  pricePerAthlete: 60,  spotsLeft: 20, total: 32 },
];

const AVATAR_IMGS = [
  imgRectangle4, imgRectangle5, imgRectangle6, imgRectangle7,
  imgRectangle8, imgRectangle9, imgRectangle10,
];

const MOCK_USERS = [
  { id: 'u1', nickname: 'joaosilva',     name: 'João Silva',      avatar: AVATAR_IMGS[0] },
  { id: 'u2', nickname: 'mariaoliveira', name: 'Maria Oliveira',  avatar: AVATAR_IMGS[1] },
  { id: 'u3', nickname: 'pedrocosta',    name: 'Pedro Costa',     avatar: AVATAR_IMGS[2] },
  { id: 'u4', nickname: 'anasantos',     name: 'Ana Santos',      avatar: AVATAR_IMGS[3] },
  { id: 'u5', nickname: 'carlosmelo',    name: 'Carlos Melo',     avatar: AVATAR_IMGS[4] },
  { id: 'u6', nickname: 'fernanda_b',    name: 'Fernanda Barros', avatar: AVATAR_IMGS[5] },
  { id: 'u7', nickname: 'lucas_praia',   name: 'Lucas Praia',     avatar: AVATAR_IMGS[6] },
];

const COUPON_CODES: Record<string, number> = {
  PRAIA25: 0.25, AMIGO10: 0.10, BEACH50: 0.50,
};

const SIZES             = ['PP', 'P', 'M', 'G', 'GG', 'XGG'];
const SERVICE_FEE_RATE  = 0.03;   // 3% taxa de plataforma
const MULTI_CAT_DISCOUNT = 0.50;  // 50% off só para o usuário logado, a partir da 2ª categoria

const PIX_CODE =
  '00020126580014br.gov.bcb.pix0136550e4fc2-d2a9-4b2d-9d0c-4e3bbf534d755204000053039865802BR5925Praia Cup Organizacao6007Ilheus6304E8B2';

const STEP_ORDER: CheckoutStep[] = [
  'auth','categories','partners','uniforms','review','billing','payment-method','payment-details','success',
];
const VISIBLE_STEPS: CheckoutStep[] = [
  'auth','categories','partners','uniforms','review','billing','payment-method',
];
const STEP_LABELS: Partial<Record<CheckoutStep, string>> = {
  auth: 'Acesso', categories: 'Categorias', partners: 'Dupla',
  uniforms: 'Uniforme', review: 'Revisão', billing: 'Faturamento',
  'payment-method': 'Pagamento',
};

const INITIAL_DATA: CheckoutData = {
  user: null, selectedCategories: [], partners: {}, uniforms: {},
  billing: { name: '', cpf: '', email: '' },
  couponCode: '', couponStatus: 'idle', couponDiscount: 0,
  payOptions: {},
  paymentMethod: null,
};

// ─── Pricing ─────────────────────────────────────────────────────────────────
/**
 * Preço do USUÁRIO LOGADO por categoria.
 * O desconto de 50% se aplica somente a partir da 2ª categoria selecionada pelo usuário.
 */
const myAthletePrice = (catIdx: number, pricePerAthlete: number): number =>
  catIdx === 0 ? pricePerAthlete : pricePerAthlete * (1 - MULTI_CAT_DISCOUNT);

/**
 * Preço da DUPLA por categoria — sempre o valor integral, sem desconto,
 * independentemente de quantas categorias o usuário principal está inscrevendo.
 */
const partnerAthletePrice = (pricePerAthlete: number): number => pricePerAthlete;

interface PricingLine {
  cat: Category;
  idx: number;
  myPrice: number;       // preço do usuário logado (pode ter desconto)
  partnerPrice: number;  // preço da dupla (sempre integral)
  hasPartner: boolean;
  isDiscounted: boolean; // true quando idx > 0
  payOption: 'full' | 'mine';
  // Quanto o usuário paga nesta linha
  userPays: number;
  // Quanto a dupla terá de pagar (se payOption === 'mine')
  partnerOwes: number;
}

interface PricingResult {
  lines: PricingLine[];
  userBaseTotal: number;   // soma do que o usuário paga antes de desconto de cupom
  couponAmt: number;
  afterCoupon: number;
  serviceFee: number;
  total: number;           // total final cobrado do usuário
  partnerTotalOwed: number; // soma que fica sob responsabilidade das duplas
}

const computePricing = (data: CheckoutData): PricingResult => {
  const lines: PricingLine[] = data.selectedCategories.map((cat, idx) => {
    const myPrice      = myAthletePrice(idx, cat.pricePerAthlete);
    const partnerPrice = partnerAthletePrice(cat.pricePerAthlete);
    const hasPartner   = data.partners[cat.id] != null;
    const payOption    = data.payOptions[cat.id] ?? 'full';

    const userPays    = payOption === 'full' && hasPartner
      ? myPrice + partnerPrice
      : myPrice;

    const partnerOwes = (payOption === 'mine' && hasPartner) ? partnerPrice : 0;

    return {
      cat, idx, myPrice, partnerPrice, hasPartner,
      isDiscounted: idx > 0, payOption, userPays, partnerOwes,
    };
  });

  const userBaseTotal    = lines.reduce((s, l) => s + l.userPays, 0);
  const couponAmt        = data.couponStatus === 'valid'
    ? userBaseTotal * data.couponDiscount : 0;
  const afterCoupon      = userBaseTotal - couponAmt;
  const serviceFee       = afterCoupon * SERVICE_FEE_RATE;
  const total            = afterCoupon + serviceFee;
  const partnerTotalOwed = lines.reduce((s, l) => s + l.partnerOwes, 0);

  return { lines, userBaseTotal, couponAmt, afterCoupon, serviceFee, total, partnerTotalOwed };
};

// ─── Formatters ───────────────────────────────────────────────────────────────
const fmt    = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const fmtCPF = (v: string) => {
  const d = v.replace(/\D/g, '').slice(0, 11);
  if (d.length <= 3) return d;
  if (d.length <= 6) return `${d.slice(0,3)}.${d.slice(3)}`;
  if (d.length <= 9) return `${d.slice(0,3)}.${d.slice(3,6)}.${d.slice(6)}`;
  return `${d.slice(0,3)}.${d.slice(3,6)}.${d.slice(6,9)}-${d.slice(9,11)}`;
};
const fmtCard   = (v: string) => v.replace(/\D/g,'').slice(0,16).replace(/(\d{4})(?=\d)/g,'$1 ');
const fmtExpiry = (v: string) => { const d=v.replace(/\D/g,'').slice(0,4); return d.length>2?`${d.slice(0,2)}/${d.slice(2)}`:d; };
const cardBrand = (n: string) => {
  const s = n.replace(/\s/g,'');
  if (/^4/.test(s))                   return 'Visa';
  if (/^5[1-5]/.test(s)||/^2[2-7]/.test(s)) return 'Mastercard';
  if (/^3[47]/.test(s))               return 'Amex';
  if (/^6/.test(s))                   return 'Elo';
  return null;
};

// ─── Shared UI ────────────────────────────────────────────────────────────────
function Btn({ onClick, disabled, variant='primary', type='button', className='', children, fullWidth }: {
  onClick?: ()=>void; disabled?: boolean; variant?: 'primary'|'secondary'|'ghost';
  type?: 'button'|'submit'; className?: string; children: React.ReactNode; fullWidth?: boolean;
}) {
  const base = 'inline-flex items-center justify-center gap-2 rounded-[100px] px-6 h-[48px] transition-all text-[14px] font-semibold whitespace-nowrap';
  const vs = {
    primary:   'bg-[#3ECF8E] text-[#121212] hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed',
    secondary: 'bg-[#2f2f2f] text-white hover:bg-[#3a3a3a] disabled:opacity-40',
    ghost:     'text-[#8e8e8e] hover:text-white h-auto px-2',
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled}
      className={`${base} ${vs[variant]} ${fullWidth?'w-full':''} ${className}`}>
      {children}
    </button>
  );
}

function Field({ label, value, onChange, placeholder, type='text', error, suffix, disabled, autoFocus }: {
  label?: string; value: string; onChange: (v:string)=>void; placeholder?: string;
  type?: string; error?: string; suffix?: React.ReactNode; disabled?: boolean; autoFocus?: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5 w-full">
      {label && <label className="text-[13px] text-[#8e8e8e]">{label}</label>}
      <div className={`flex items-center gap-2 bg-[#1c1c1c] border rounded-[8px] px-3 h-[48px] transition-colors
        ${error?'border-[#e5534b]':'border-[#3c3c3c] focus-within:border-[#3ECF8E]'} ${disabled?'opacity-50':''}`}>
        <input type={type} value={value} onChange={e=>onChange(e.target.value)}
          placeholder={placeholder} disabled={disabled} autoFocus={autoFocus}
          className="flex-1 bg-transparent text-white text-[14px] outline-none placeholder-[#4a4a4a] min-w-0"/>
        {suffix && <div className="shrink-0">{suffix}</div>}
      </div>
      {error && (
        <p className="text-[12px] text-[#e5534b] flex items-center gap-1">
          <AlertCircle size={12}/>{error}
        </p>
      )}
    </div>
  );
}

function Card({ children, className='' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-[#1c1c1c] border border-[#2a2a2a] rounded-[16px] p-6 ${className}`}>
      {children}
    </div>
  );
}

function StepHeading({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h2 className="text-white text-[22px] font-semibold leading-tight mb-1">{title}</h2>
      {subtitle && <p className="text-[#8e8e8e] text-[14px]">{subtitle}</p>}
    </div>
  );
}

function Nav({ onBack, onNext, nextLabel='Continuar', nextDisabled=false }: {
  onBack?: ()=>void; onNext?: ()=>void; nextLabel?: string; nextDisabled?: boolean;
}) {
  return (
    <div className="flex items-center justify-between mt-5">
      {onBack ? <Btn variant="ghost" onClick={onBack}><ArrowLeft size={16}/>Voltar</Btn> : <div/>}
      {onNext && <Btn onClick={onNext} disabled={nextDisabled}>{nextLabel}<ChevronRight size={16}/></Btn>}
    </div>
  );
}

function InfoBox({ children, color='blue' }: { children: React.ReactNode; color?: 'blue'|'green'|'amber' }) {
  const c = {
    blue:  'bg-blue-500/10 border-blue-500/20 text-blue-300',
    green: 'bg-[#3ECF8E]/10 border-[#3ECF8E]/20 text-[#3ECF8E]',
    amber: 'bg-amber-500/10 border-amber-500/20 text-amber-300',
  };
  return (
    <div className={`flex gap-2.5 p-3 rounded-[10px] border text-[12px] leading-relaxed ${c[color]}`}>
      <Info size={14} className="shrink-0 mt-0.5"/>
      <div>{children}</div>
    </div>
  );
}

// ─── 1. EVENT BANNER — 1092×355 px com borda arredondada de 12px ─────────────
function EventBanner() {
  return (
    <div className="w-full px-4 pt-3 pb-0">
      <div
        className="relative overflow-hidden mx-auto"
        style={{ width: '100%', maxWidth: 1092, height: 355, borderRadius: 12 }}
      >
        <img
          src={imgBanner}
          alt="Praia Cup — capa do evento"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        {/* Gradient apenas no rodapé para legibilidade */}
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-black/70 to-transparent"/>
        <div className="absolute bottom-4 left-0 right-0 px-5 flex items-end justify-between">
          <div>
            <p className="text-white font-semibold text-[16px] leading-tight drop-shadow">Praia Cup</p>
            <p className="text-white/60 text-[12px] drop-shadow">11ª Etapa 2025 · 12–15 Set · Ilhéus / BA</p>
          </div>
          <span className="text-[10px] font-semibold text-[#3ECF8E] bg-[#3ECF8E]/15 border border-[#3ECF8E]/30 px-2 py-0.5 rounded-full">
            Inscrições abertas
          </span>
        </div>
      </div>
    </div>
  );
}

// ─── Step Indicator ───────────────────────────────────────────────────────────
function StepIndicator({ current }: { current: CheckoutStep }) {
  const ci = VISIBLE_STEPS.indexOf(
    current === 'payment-details' ? 'payment-method' : current,
  );
  return (
    <div className="flex items-center justify-center gap-1 py-4 max-w-3xl mx-auto w-full px-4">
      {VISIBLE_STEPS.map((s, i) => {
        const done = i < ci, active = i === ci;
        return (
          <React.Fragment key={s}>
            <div className="flex flex-col items-center gap-1 shrink-0">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center transition-all
                ${done   ? 'bg-[#3ECF8E]'
                : active ? 'bg-[#3ECF8E] ring-4 ring-[#3ECF8E]/20'
                         : 'bg-[#232323] border border-[#3c3c3c]'}`}>
                {done
                  ? <Check size={12} className="text-[#121212]"/>
                  : <span className={`text-[10px] font-bold ${active?'text-[#121212]':'text-[#4a4a4a]'}`}>{i+1}</span>}
              </div>
              <span className={`text-[9px] uppercase tracking-wider hidden sm:block
                ${active?'text-white':done?'text-[#3ECF8E]':'text-[#3a3a3a]'}`}>{STEP_LABELS[s]}</span>
            </div>
            {i < VISIBLE_STEPS.length-1 && (
              <div className={`flex-1 h-px mb-4 transition-all ${i<ci?'bg-[#3ECF8E]':'bg-[#2a2a2a]'}`}/>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

// ─── STEP 1: Auth ─────────────────────────────────────────────────────────────
function AuthStep({ onUpdate, onNext }: {
  onUpdate: (u: Partial<CheckoutData>) => void; onNext: () => void;
}) {
  const [mode, setMode]         = useState<'login'|'register'>('login');
  const [email, setEmail]       = useState('atleta@praia.cup');
  const [password, setPassword] = useState('demo1234');
  const [name, setName]         = useState('');
  const [confirm, setConfirm]   = useState('');
  const [errs, setErrs]         = useState<Record<string,string>>({});

  const submit = () => {
    const e: Record<string,string> = {};
    if (!email.includes('@'))   e.email = 'Email inválido';
    if (password.length < 6)    e.password = 'Mínimo 6 caracteres';
    if (mode === 'register') {
      if (name.trim().length < 2) e.name = 'Nome obrigatório';
      if (password !== confirm)   e.confirm = 'Senhas não conferem';
    }
    if (Object.keys(e).length) { setErrs(e); return; }
    onUpdate({ user: { name: mode === 'register' ? name.trim() : 'Atleta Demo', email } });
    onNext();
  };

  return (
    <Card>
      <StepHeading
        title={mode === 'login' ? 'Bem-vindo(a) de volta!' : 'Criar conta'}
        subtitle={mode === 'login'
          ? 'Entre para continuar sua inscrição no Praia Cup'
          : 'Crie sua conta para se inscrever'}
      />
      <div className="flex flex-col gap-4">
        {mode === 'register' && (
          <Field label="Nome completo" value={name}
            onChange={v=>{setName(v);setErrs(e=>({...e,name:''}))}}
            placeholder="Seu nome completo" error={errs.name}/>
        )}
        <Field label="Email" type="email" value={email}
          onChange={v=>{setEmail(v);setErrs(e=>({...e,email:''}))}}
          placeholder="seu@email.com" error={errs.email}/>
        <Field label="Senha" type="password" value={password}
          onChange={v=>{setPassword(v);setErrs(e=>({...e,password:''}))}}
          placeholder="••••••••" error={errs.password}/>
        {mode === 'register' && (
          <Field label="Confirmar senha" type="password" value={confirm}
            onChange={v=>{setConfirm(v);setErrs(e=>({...e,confirm:''}))}}
            placeholder="••••••••" error={errs.confirm}/>
        )}
      </div>
      <div className="mt-6 flex flex-col gap-3">
        <Btn onClick={submit} fullWidth>{mode === 'login' ? 'Entrar' : 'Criar conta'}</Btn>
        {mode === 'login' && (
          <p className="text-center text-[11px] text-[#3a3a3a]">Demo: use qualquer email e senha válidos</p>
        )}
      </div>
      <div className="mt-4 text-center">
        <span className="text-[14px] text-[#8e8e8e]">{mode==='login'?'Não tem conta? ':'Já tem conta? '}</span>
        <button onClick={()=>{setMode(m=>m==='login'?'register':'login');setErrs({})}}
          className="text-[14px] text-[#3ECF8E] hover:underline">
          {mode==='login'?'Criar conta':'Entrar'}
        </button>
      </div>
    </Card>
  );
}

// ─── STEP 2: Categories ───────────────────────────────────────────────────────
function CategoryStep({ data, onUpdate, onNext, onBack }: {
  data: CheckoutData; onUpdate: (u: Partial<CheckoutData>) => void;
  onNext: () => void; onBack: () => void;
}) {
  const toggle = (cat: Category) => {
    const exists = data.selectedCategories.find(c => c.id === cat.id);
    onUpdate({
      selectedCategories: exists
        ? data.selectedCategories.filter(c => c.id !== cat.id)
        : [...data.selectedCategories, cat],
    });
  };

  const selectedCount = data.selectedCategories.length;
  const myPreview     = data.selectedCategories.reduce(
    (s, cat, idx) => s + myAthletePrice(idx, cat.pricePerAthlete), 0,
  );

  return (
    <>
      <Card>
        <StepHeading title="Escolha sua(s) categoria(s)"
          subtitle="Selecione uma ou mais categorias para se inscrever"/>

        <div className="mb-4">
          <InfoBox color="blue">
            <span className="font-medium text-white">Desconto multi-categoria (para você):</span>
            {' '}a 2ª+ categoria tem <span className="font-semibold text-white">50% de desconto</span> no
            valor do seu ingresso. Sua dupla paga o valor integral de cada categoria.
            Esta regra é definida pelo organizador no cadastro do evento.
          </InfoBox>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {CATEGORIES.map(cat => {
            const sel      = !!data.selectedCategories.find(c => c.id === cat.id);
            const sold     = cat.spotsLeft === 0;
            const wouldIdx = sel
              ? data.selectedCategories.findIndex(c => c.id === cat.id)
              : selectedCount;
            const previewPrice = myAthletePrice(wouldIdx, cat.pricePerAthlete);
            const isDisc       = wouldIdx > 0;

            return (
              <button key={cat.id} onClick={() => !sold && toggle(cat)} disabled={sold}
                className={`relative text-left p-4 rounded-[12px] border transition-all
                  ${sold ? 'opacity-40 cursor-not-allowed border-[#2a2a2a] bg-[#191919]'
                    : sel ? 'border-[#3ECF8E] bg-[#3ECF8E]/10 ring-1 ring-[#3ECF8E]/20'
                          : 'border-[#2a2a2a] bg-[#171717] hover:border-[#4a4a4a]'}`}>
                {sel && !sold && (
                  <div className="absolute top-3 right-3 w-5 h-5 bg-[#3ECF8E] rounded-full flex items-center justify-center">
                    <Check size={11} className="text-[#121212]"/>
                  </div>
                )}
                {sold && (
                  <span className="absolute top-3 right-3 text-[10px] bg-[#2f2f2f] text-[#8e8e8e] px-2 py-0.5 rounded-full">
                    Esgotado
                  </span>
                )}
                <p className="text-white font-semibold text-[15px]">{cat.name}</p>
                <p className="text-[#8e8e8e] text-[12px] mt-0.5">{cat.gender}</p>

                <div className="mt-3 space-y-1">
                  {/* My price row */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-[#4a4a4a] w-14 shrink-0">Você:</span>
                    {isDisc ? (
                      <>
                        <span className="text-[11px] text-[#4a4a4a] line-through">{fmt(cat.pricePerAthlete)}</span>
                        <span className="text-[#3ECF8E] font-semibold text-[13px]">{fmt(previewPrice)}</span>
                        <span className="text-[10px] bg-[#3ECF8E]/20 text-[#3ECF8E] px-1 py-0.5 rounded-full font-semibold">−50%</span>
                      </>
                    ) : (
                      <span className="text-[#3ECF8E] font-semibold text-[13px]">{fmt(cat.pricePerAthlete)}</span>
                    )}
                  </div>
                  {/* Partner price row (always full) */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-[#4a4a4a] w-14 shrink-0">Dupla:</span>
                    <span className="text-[#8e8e8e] text-[12px]">{fmt(cat.pricePerAthlete)}</span>
                  </div>
                </div>

                {!sold && (
                  <p className="text-[10px] text-[#3a3a3a] mt-2">{cat.spotsLeft}/{cat.total} vagas</p>
                )}
              </button>
            );
          })}
        </div>

        {selectedCount > 0 && (
          <div className="mt-4 px-4 py-3 bg-[#171717] rounded-[10px] border border-[#2a2a2a] flex items-center justify-between">
            <div>
              <p className="text-[#8e8e8e] text-[13px]">{selectedCount} categoria(s) · sua parte estimada</p>
              {selectedCount > 1 && (
                <p className="text-[11px] text-[#3ECF8E] mt-0.5">
                  Desconto de 50% aplicado na {selectedCount > 2 ? `2ª–${selectedCount}ª` : '2ª'} categoria
                </p>
              )}
            </div>
            <span className="text-[#3ECF8E] font-semibold text-[17px]">{fmt(myPreview)}</span>
          </div>
        )}
      </Card>
      <Nav onBack={onBack} onNext={onNext} nextDisabled={selectedCount === 0}/>
    </>
  );
}

// ─── STEP 3: Partners ─────────────────────────────────────────────────────────
function PartnerSearch({ category, catIdx, partner, onSelect, userName }: {
  category: Category; catIdx: number; partner: Partner | null;
  onSelect: (p: Partner | null) => void; userName: string;
}) {
  const [q, setQ]                 = useState('');
  const [results, setResults]     = useState<typeof MOCK_USERS>([]);
  const [searching, setSearching] = useState(false);
  const [open, setOpen]           = useState(false);
  const [modal, setModal]         = useState(false);
  // ─ Pré-cadastro: campos obrigatórios completos
  const [pre, setPre] = useState({ name: '', email: '', cpf: '', phone: '' });
  const timer = useRef<ReturnType<typeof setTimeout>>();
  const wrap  = useRef<HTMLDivElement>(null);

  const myPrice      = myAthletePrice(catIdx, category.pricePerAthlete);
  const pPartnerPrice = partnerAthletePrice(category.pricePerAthlete);
  const pairPrice    = myPrice + pPartnerPrice;

  const search = (val: string) => {
    setQ(val); clearTimeout(timer.current);
    if (!val.trim()) { setResults([]); setOpen(false); return; }
    setSearching(true); setOpen(true);
    timer.current = setTimeout(() => {
      const norm = val.toLowerCase().replace('@','');
      setResults(MOCK_USERS.filter(u =>
        u.nickname.toLowerCase().includes(norm) || u.name.toLowerCase().includes(norm)));
      setSearching(false);
    }, 400);
  };

  useEffect(() => () => clearTimeout(timer.current), []);
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  useEffect(() => {
    if (!partner) { setQ(''); setResults([]); setOpen(false); }
  }, [partner?.id]);

  const submitPre = () => {
    if (!pre.name.trim() || !pre.email.trim() || pre.cpf.replace(/\D/g,'').length < 11) return;
    onSelect({
      id: `pre-${Date.now()}`,
      nickname: pre.name.toLowerCase().replace(/\s+/g,'_'),
      name: pre.name.trim(),
      isPrecadastro: true,
      precadastroEmail: pre.email,
      precadastroCpf:   pre.cpf,
      precadastroPhone: pre.phone,
    });
    setModal(false);
    setPre({ name:'', email:'', cpf:'', phone:'' });
  };

  const preCanSubmit =
    pre.name.trim().length >= 2 &&
    pre.email.includes('@') &&
    pre.cpf.replace(/\D/g,'').length === 11;

  return (
    <div className="border border-[#2a2a2a] rounded-[12px] p-4 bg-[#171717]">
      {/* Header */}
      <div className="flex items-start justify-between mb-1">
        <div>
          <p className="text-white font-semibold">{category.name}</p>
          <p className="text-[#8e8e8e] text-[12px]">{category.gender}</p>
        </div>
        <div className="text-right">
          {partner ? (
            <>
              <p className="text-[#3ECF8E] font-semibold text-[15px]">{fmt(pairPrice)}</p>
              <p className="text-[10px] text-[#3ECF8E]/70">dupla ({fmt(myPrice)} + {fmt(pPartnerPrice)})</p>
            </>
          ) : (
            <>
              <p className="text-[#8e8e8e] text-[13px]">{fmt(myPrice)} <span className="text-[11px]">você</span></p>
              <p className="text-[10px] text-[#4a4a4a]">+ dupla → {fmt(pairPrice)}</p>
            </>
          )}
          {catIdx > 0 && (
            <span className="text-[10px] text-[#3ECF8E] font-semibold">
              50% off (sua parte)
            </span>
          )}
        </div>
      </div>

      <div className="border-t border-[#252525] my-3"/>

      {/* Me */}
      <div className="flex items-center gap-3 mb-3">
        <img src={imgSynergy} className="w-8 h-8 rounded-full object-cover shrink-0" alt="Você"/>
        <div className="flex-1 min-w-0">
          <p className="text-white text-[13px] font-medium">{userName}</p>
          <p className="text-[#4a4a4a] text-[11px]">você</p>
        </div>
        <span className="text-[#3ECF8E] text-[12px] font-medium">{fmt(myPrice)}</span>
      </div>

      {/* Partner row */}
      {partner ? (
        <div className="flex items-center gap-3 bg-[#1c1c1c] rounded-[8px] p-3">
          {partner.avatar
            ? <img src={partner.avatar} className="w-8 h-8 rounded-full object-cover shrink-0" alt={partner.name}/>
            : <div className="w-8 h-8 rounded-full bg-[#3ECF8E]/20 flex items-center justify-center shrink-0">
                <Users size={14} className="text-[#3ECF8E]"/>
              </div>}
          <div className="flex-1 min-w-0">
            <p className="text-white text-[13px] font-medium truncate">{partner.name}</p>
            <p className="text-[#8e8e8e] text-[11px]">
              @{partner.nickname}{partner.isPrecadastro ? ' · pré-cadastro' : ''}
            </p>
          </div>
          {/* Partner always pays full price */}
          <span className="text-[#8e8e8e] text-[12px] font-medium mr-2">{fmt(pPartnerPrice)}</span>
          <button onClick={() => onSelect(null)} className="text-[#4a4a4a] hover:text-white transition-colors">
            <X size={15}/>
          </button>
        </div>
      ) : (
        <div ref={wrap} className="relative">
          <div className={`flex items-center gap-2 bg-[#1c1c1c] border rounded-[8px] px-3 h-[44px] transition-colors
            ${open?'border-[#3ECF8E]':'border-[#3c3c3c]'}`}>
            <Search size={14} className="text-[#4a4a4a] shrink-0"/>
            <input value={q} onChange={e=>search(e.target.value)} onFocus={()=>q&&setOpen(true)}
              placeholder="@nickname da dupla"
              className="flex-1 bg-transparent text-white text-[14px] outline-none placeholder-[#3a3a3a] min-w-0"/>
            {searching && (
              <div className="w-4 h-4 border-2 border-[#3ECF8E] border-t-transparent rounded-full animate-spin shrink-0"/>
            )}
          </div>
          {open && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-[#252525] border border-[#3c3c3c] rounded-[10px] overflow-hidden z-50 shadow-2xl">
              {results.length > 0
                ? results.map(u => (
                  <button key={u.id} onClick={() => {
                    onSelect({ id:u.id, nickname:u.nickname, name:u.name, avatar:u.avatar });
                    setOpen(false); setQ('');
                  }} className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-[#333] transition-colors text-left">
                    <img src={u.avatar} className="w-8 h-8 rounded-full object-cover shrink-0" alt={u.name}/>
                    <div>
                      <p className="text-white text-[13px]">{u.name}</p>
                      <p className="text-[#8e8e8e] text-[11px]">@{u.nickname}</p>
                    </div>
                  </button>
                ))
                : !searching && q ? (
                  <div className="p-4 text-center">
                    <p className="text-[#8e8e8e] text-[13px] mb-3">
                      Nenhum atleta encontrado com "@{q.replace('@','')}"
                    </p>
                    <button onClick={() => { setOpen(false); setModal(true); }}
                      className="text-[13px] text-[#3ECF8E] hover:underline">
                      + Convidar / Pré-cadastro
                    </button>
                  </div>
                ) : null}
            </div>
          )}
        </div>
      )}

      {/* ── 3. PRÉ-CADASTRO MODAL com campos completos ── */}
      {modal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80">
          <div className="bg-[#1c1c1c] border border-[#2a2a2a] rounded-[16px] p-6 w-full max-w-sm shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white font-semibold">Pré-cadastro da dupla</h3>
              <button onClick={() => setModal(false)} className="text-[#8e8e8e] hover:text-white">
                <X size={18}/>
              </button>
            </div>
            <p className="text-[#8e8e8e] text-[12px] mb-4 leading-relaxed">
              A dupla não precisa ter conta agora. Preencha os dados para reservar a vaga —
              um convite com os dados de acesso e cobrança será enviado por e-mail.
            </p>
            <div className="flex flex-col gap-3">
              {/* Nome completo */}
              <Field label="Nome completo *" value={pre.name}
                onChange={v => setPre(p => ({ ...p, name: v }))}
                placeholder="Nome da dupla"/>
              {/* Email */}
              <Field label="E-mail *" type="email" value={pre.email}
                onChange={v => setPre(p => ({ ...p, email: v }))}
                placeholder="email@dupla.com"/>
              {/* CPF */}
              <Field label="CPF *" value={pre.cpf}
                onChange={v => setPre(p => ({ ...p, cpf: fmtCPF(v) }))}
                placeholder="000.000.000-00"/>
              {/* WhatsApp */}
              <Field label="WhatsApp" value={pre.phone}
                onChange={v => setPre(p => ({ ...p, phone: v }))}
                placeholder="(xx) xxxxx-xxxx"/>
            </div>
            <p className="text-[11px] text-[#3a3a3a] mt-2">* campos obrigatórios</p>
            <div className="flex gap-3 mt-4">
              <Btn variant="secondary" onClick={() => setModal(false)} fullWidth>Cancelar</Btn>
              <Btn onClick={submitPre} disabled={!preCanSubmit} fullWidth>Reservar vaga</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PartnerStep({ data, onUpdate, onNext, onBack }: {
  data: CheckoutData; onUpdate: (u: Partial<CheckoutData>) => void;
  onNext: () => void; onBack: () => void;
}) {
  const allDone = data.selectedCategories.every(c => data.partners[c.id] != null);

  const myTotal      = data.selectedCategories.reduce((s,cat,idx) => s + myAthletePrice(idx, cat.pricePerAthlete), 0);
  const partnerTotal = data.selectedCategories.reduce((s,cat) =>
    s + (data.partners[cat.id] ? partnerAthletePrice(cat.pricePerAthlete) : 0), 0);

  return (
    <>
      <Card>
        <StepHeading title="Informe sua dupla"
          subtitle="Busque e vincule seu parceiro(a) em cada categoria"/>
        <div className="flex flex-col gap-4">
          {data.selectedCategories.map((cat, idx) => (
            <PartnerSearch key={cat.id} category={cat} catIdx={idx}
              partner={data.partners[cat.id] ?? null}
              onSelect={p => onUpdate({ partners: { ...data.partners, [cat.id]: p } })}
              userName={data.user?.name ?? 'Você'}/>
          ))}
        </div>
        {allDone && (
          <div className="mt-4 p-3 bg-[#171717] rounded-[10px] border border-[#3ECF8E]/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white text-[13px] font-medium">Total da inscrição (dupla)</p>
                <p className="text-[#8e8e8e] text-[11px]">
                  Sua parte: {fmt(myTotal)} · Duplas: {fmt(partnerTotal)}
                </p>
              </div>
              <span className="text-[#3ECF8E] font-semibold text-[18px]">{fmt(myTotal + partnerTotal)}</span>
            </div>
          </div>
        )}
      </Card>
      <Nav onBack={onBack} onNext={onNext} nextDisabled={!allDone}/>
    </>
  );
}

// ─── STEP 4: Uniforms ─────────────────────────────────────────────────────────
function UniformStep({ data, onUpdate, onNext, onBack }: {
  data: CheckoutData; onUpdate: (u: Partial<CheckoutData>) => void;
  onNext: () => void; onBack: () => void;
}) {
  const getU   = (id: string) => data.uniforms[id] || { me:'', partner:'' };
  const setU   = (id: string, who: 'me'|'partner', sz: string) =>
    onUpdate({ uniforms: { ...data.uniforms, [id]: { ...getU(id), [who]: sz } } });
  const allDone = data.selectedCategories.every(c => { const u=getU(c.id); return u.me && u.partner; });

  return (
    <>
      <Card>
        <StepHeading title="Tamanho do uniforme"
          subtitle="Selecione o tamanho para você e sua dupla em cada categoria"/>
        <div className="flex flex-col gap-5">
          {data.selectedCategories.map(cat => {
            const partner = data.partners[cat.id];
            const u       = getU(cat.id);
            return (
              <div key={cat.id} className="border border-[#2a2a2a] rounded-[12px] p-4 bg-[#171717]">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-white font-semibold">{cat.name}</p>
                    <p className="text-[#8e8e8e] text-[12px]">{cat.gender}</p>
                  </div>
                  <button className="text-[12px] text-[#3ECF8E] hover:underline"
                    onClick={e => e.preventDefault()}>Guia de medidas</button>
                </div>
                {/* My size */}
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2.5">
                    <img src={imgSynergy} className="w-6 h-6 rounded-full object-cover" alt=""/>
                    <span className="text-white text-[13px]">{data.user?.name ?? 'Você'}</span>
                    <span className="text-[10px] text-[#4a4a4a] bg-[#252525] px-1.5 py-0.5 rounded-full">você</span>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {SIZES.map(sz => (
                      <button key={sz} onClick={() => setU(cat.id,'me',sz)}
                        className={`px-3 py-1.5 rounded-[6px] text-[12px] font-semibold transition-all border
                          ${u.me===sz
                            ?'bg-[#3ECF8E] text-[#121212] border-[#3ECF8E]'
                            :'bg-transparent text-[#8e8e8e] border-[#3c3c3c] hover:border-[#8e8e8e]'}`}>{sz}</button>
                    ))}
                  </div>
                </div>
                {/* Partner size */}
                {partner && (
                  <div>
                    <div className="flex items-center gap-2 mb-2.5">
                      {partner.avatar
                        ? <img src={partner.avatar} className="w-6 h-6 rounded-full object-cover" alt=""/>
                        : <div className="w-6 h-6 rounded-full bg-[#2f2f2f] flex items-center justify-center">
                            <Users size={10} className="text-[#8e8e8e]"/>
                          </div>}
                      <span className="text-white text-[13px]">{partner.name}</span>
                      {partner.isPrecadastro && (
                        <span className="text-[10px] text-[#4a4a4a] bg-[#252525] px-1.5 py-0.5 rounded-full">pré-cadastro</span>
                      )}
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      {SIZES.map(sz => (
                        <button key={sz} onClick={() => setU(cat.id,'partner',sz)}
                          className={`px-3 py-1.5 rounded-[6px] text-[12px] font-semibold transition-all border
                            ${u.partner===sz
                              ?'bg-[#3ECF8E] text-[#121212] border-[#3ECF8E]'
                              :'bg-transparent text-[#8e8e8e] border-[#3c3c3c] hover:border-[#8e8e8e]'}`}>{sz}</button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>
      <Nav onBack={onBack} onNext={onNext} nextDisabled={!allDone}/>
    </>
  );
}

// ─── STEP 5: Review — divisão de pagamento POR CATEGORIA ─────────────────────
function PaySplitBlock({ cat, catIdx, partner, payOption, onSetOption }: {
  cat: Category; catIdx: number; partner: Partner | null;
  payOption: 'full' | 'mine'; onSetOption: (v: 'full' | 'mine') => void;
}) {
  const myPrice      = myAthletePrice(catIdx, cat.pricePerAthlete);
  const pPrice       = partnerAthletePrice(cat.pricePerAthlete);
  const pairTotal    = myPrice + pPrice;

  return (
    <div className="border border-[#252525] rounded-[10px] p-4 bg-[#171717] mt-3">
      {/* Category label */}
      <div className="flex items-center gap-2 mb-3">
        <p className="text-white text-[13px] font-semibold">{cat.name}</p>
        <span className="text-[10px] bg-[#2a2a2a] text-[#8e8e8e] px-1.5 py-0.5 rounded-full">{cat.gender}</span>
        {catIdx > 0 && (
          <span className="text-[10px] bg-[#3ECF8E]/20 text-[#3ECF8E] px-1.5 py-0.5 rounded-full font-semibold">
            −50% (você)
          </span>
        )}
      </div>

      {/* Duo summary */}
      <div className="flex items-center justify-between mb-4 text-[12px]">
        <div className="flex items-center gap-2">
          <img src={imgSynergy} className="w-5 h-5 rounded-full object-cover" alt=""/>
          <span className="text-[#8e8e8e]">Você</span>
          <span className="text-white font-semibold">{fmt(myPrice)}</span>
        </div>
        {partner && (
          <div className="flex items-center gap-2">
            {partner.avatar
              ? <img src={partner.avatar} className="w-5 h-5 rounded-full object-cover" alt=""/>
              : <div className="w-5 h-5 rounded-full bg-[#2f2f2f] flex items-center justify-center"><Users size={9} className="text-[#8e8e8e]"/></div>}
            <span className="text-[#8e8e8e] truncate max-w-[100px]">{partner.name}</span>
            <span className="text-white font-semibold">{fmt(pPrice)}</span>
          </div>
        )}
      </div>

      {/* Split radio buttons */}
      <div className="flex flex-col gap-2">
        {/* Full */}
        <button onClick={() => onSetOption('full')}
          className={`w-full text-left p-3 rounded-[8px] border transition-all flex items-center gap-3
            ${payOption==='full'
              ?'border-[#3ECF8E] bg-[#3ECF8E]/10'
              :'border-[#2a2a2a] bg-[#1a1a1a] hover:border-[#4a4a4a]'}`}>
          <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 transition-all
            ${payOption==='full'?'border-[#3ECF8E] bg-[#3ECF8E]':'border-[#4a4a4a]'}`}>
            {payOption==='full' && <div className="w-1.5 h-1.5 rounded-full bg-[#121212]"/>}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-[12px] font-medium">Pagar total da dupla</p>
            <p className="text-[#8e8e8e] text-[11px]">Você cobre os dois</p>
          </div>
          <span className="text-[#3ECF8E] font-semibold text-[13px] shrink-0">{fmt(pairTotal)}</span>
        </button>

        {/* Mine only */}
        <button onClick={() => onSetOption('mine')}
          className={`w-full text-left p-3 rounded-[8px] border transition-all flex items-center gap-3
            ${payOption==='mine'
              ?'border-[#3ECF8E] bg-[#3ECF8E]/10'
              :'border-[#2a2a2a] bg-[#1a1a1a] hover:border-[#4a4a4a]'}`}>
          <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 transition-all
            ${payOption==='mine'?'border-[#3ECF8E] bg-[#3ECF8E]':'border-[#4a4a4a]'}`}>
            {payOption==='mine' && <div className="w-1.5 h-1.5 rounded-full bg-[#121212]"/>}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-[12px] font-medium">Pagar somente minha parte</p>
            <p className="text-[#8e8e8e] text-[11px] truncate">
              {partner?.name ?? 'Dupla'} paga {fmt(pPrice)} separado
            </p>
          </div>
          <span className="text-[#3ECF8E] font-semibold text-[13px] shrink-0">{fmt(myPrice)}</span>
        </button>
      </div>

      {/* Partner notification info — shown per-category when 'mine' */}
      {payOption === 'mine' && partner && (
        <div className="mt-3">
          <InfoBox color="amber">
            <Mail size={12} className="inline mr-1 shrink-0"/>
            <span className="font-medium text-white">{partner.name}</span>
            {partner.precadastroEmail ? ` (${partner.precadastroEmail})` : ''}
            {' '}receberá um e-mail individual com a fatura de{' '}
            <span className="font-semibold text-white">{fmt(pPrice)}</span>
            {' '}referente à categoria <span className="font-semibold text-white">{cat.name} {cat.gender}</span>.
            Prazo: <span className="font-semibold text-white">3 dias</span> para garantir a vaga.
          </InfoBox>
        </div>
      )}
    </div>
  );
}

function ReviewStep({ data, onUpdate, onNext, onBack, onGoTo }: {
  data: CheckoutData; onUpdate: (u: Partial<CheckoutData>) => void;
  onNext: () => void; onBack: () => void; onGoTo: (s: CheckoutStep) => void;
}) {
  const setPayOption = (catId: string, val: 'full'|'mine') =>
    onUpdate({ payOptions: { ...data.payOptions, [catId]: val } });

  const pricing = computePricing(data);

  return (
    <>
      <Card>
        <StepHeading title="Revise sua inscrição"
          subtitle="Confira os dados e escolha a divisão de pagamento por categoria"/>

        {/* Athlete info */}
        <div className="border border-[#2a2a2a] rounded-[10px] p-4 mb-3">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[11px] text-[#4a4a4a] uppercase tracking-wider">Atleta</span>
            <button onClick={() => onGoTo('auth')}
              className="text-[#3ECF8E] text-[12px] flex items-center gap-1 hover:underline">
              <Edit2 size={11}/>Editar
            </button>
          </div>
          <div className="flex items-center gap-3">
            <img src={imgSynergy} className="w-10 h-10 rounded-full object-cover" alt=""/>
            <div>
              <p className="text-white font-medium">{data.user?.name}</p>
              <p className="text-[#8e8e8e] text-[13px]">{data.user?.email}</p>
            </div>
          </div>
        </div>

        {/* Per-category blocks */}
        {pricing.lines.map(({ cat, idx, myPrice, isDiscounted }) => {
          const partner = data.partners[cat.id];
          const u       = data.uniforms[cat.id] ?? { me:'–', partner:'–' };
          return (
            <div key={cat.id} className="border border-[#2a2a2a] rounded-[10px] p-4 mb-3">
              {/* Category header */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-white font-semibold">{cat.name}</span>
                  <span className="text-[11px] bg-[#2a2a2a] text-[#8e8e8e] px-2 py-0.5 rounded-full">{cat.gender}</span>
                  {isDiscounted && (
                    <span className="text-[10px] bg-[#3ECF8E]/20 text-[#3ECF8E] px-1.5 py-0.5 rounded-full font-semibold">
                      −50% (você)
                    </span>
                  )}
                </div>
                <span className="text-[#3ECF8E] font-semibold text-[13px]">{fmt(myPrice)}/você</span>
              </div>

              {/* Athlete + uniform */}
              <div className="flex flex-col gap-2 mb-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <img src={imgSynergy} className="w-6 h-6 rounded-full object-cover" alt=""/>
                    <span className="text-[13px] text-white">{data.user?.name}</span>
                    <span className="text-[11px] bg-[#2a2a2a] text-white px-1.5 py-0.5 rounded font-medium">{u.me}</span>
                  </div>
                  <button onClick={() => onGoTo('uniforms')} className="text-[#3ECF8E] hover:opacity-70"><Edit2 size={12}/></button>
                </div>
                {partner && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {partner.avatar
                        ? <img src={partner.avatar} className="w-6 h-6 rounded-full object-cover" alt=""/>
                        : <div className="w-6 h-6 rounded-full bg-[#2f2f2f] flex items-center justify-center"><Users size={10} className="text-[#8e8e8e]"/></div>}
                      <span className="text-[13px] text-white">{partner.name}</span>
                      <span className="text-[11px] text-[#4a4a4a]">@{partner.nickname}</span>
                      <span className="text-[11px] bg-[#2a2a2a] text-white px-1.5 py-0.5 rounded font-medium">{u.partner}</span>
                    </div>
                    <button onClick={() => onGoTo('partners')} className="text-[#3ECF8E] hover:opacity-70"><Edit2 size={12}/></button>
                  </div>
                )}
              </div>

              {/* Per-category payment split */}
              <PaySplitBlock
                cat={cat} catIdx={idx} partner={partner ?? null}
                payOption={data.payOptions[cat.id] ?? 'full'}
                onSetOption={v => setPayOption(cat.id, v)}/>
            </div>
          );
        })}

        {/* Running total */}
        <div className="px-4 py-3 bg-[#171717] rounded-[10px] border border-[#2a2a2a] flex items-center justify-between">
          <div>
            <p className="text-[#8e8e8e] text-[13px]">Total que você pagará</p>
            {pricing.partnerTotalOwed > 0 && (
              <p className="text-[11px] text-amber-400 mt-0.5">
                + {fmt(pricing.partnerTotalOwed)} cobrado(s) das duplas individualmente
              </p>
            )}
          </div>
          <span className="text-[#3ECF8E] font-semibold text-[18px]">
            {fmt(pricing.userBaseTotal)}
          </span>
        </div>
      </Card>
      <Nav onBack={onBack} onNext={onNext} nextLabel="Confirmar e prosseguir"/>
    </>
  );
}

// ─── STEP 6: Billing ──────────────────────────────────────────────────────────
function BillingStep({ data, onUpdate, onNext, onBack }: {
  data: CheckoutData; onUpdate: (u: Partial<CheckoutData>) => void;
  onNext: () => void; onBack: () => void;
}) {
  const [couponInput, setCouponInput] = useState(data.couponCode || '');
  const [errs, setErrs]               = useState<Record<string,string>>({});

  // Pre-fill from user session
  useEffect(() => {
    if (data.user) {
      onUpdate({
        billing: {
          name:  data.billing.name  || data.user.name,
          email: data.billing.email || data.user.email,
          cpf:   data.billing.cpf,
        },
      });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const upB = (k: keyof CheckoutData['billing'], v: string) =>
    onUpdate({ billing: { ...data.billing, [k]: v } });

  const applyCoupon = async () => {
    if (!couponInput.trim()) return;
    onUpdate({ couponStatus: 'loading' });
    await new Promise(r => setTimeout(r, 800));
    const disc = COUPON_CODES[couponInput.toUpperCase()];
    onUpdate(disc
      ? { couponStatus: 'valid', couponDiscount: disc, couponCode: couponInput.toUpperCase() }
      : { couponStatus: 'invalid', couponDiscount: 0 });
  };

  const removeCoupon = () => {
    setCouponInput('');
    onUpdate({ couponCode:'', couponStatus:'idle', couponDiscount:0 });
  };

  const validate = () => {
    const e: Record<string,string> = {};
    if (!data.billing.name.trim())                    e.name  = 'Nome obrigatório';
    if (data.billing.cpf.replace(/\D/g,'').length < 11) e.cpf = 'CPF inválido';
    if (!data.billing.email.includes('@'))            e.email = 'Email inválido';
    setErrs(e);
    return !Object.keys(e).length;
  };

  const pricing = computePricing(data);

  return (
    <>
      <Card>
        <StepHeading title="Dados de faturamento" subtitle="Confira e complete seus dados"/>

        <div className="flex flex-col gap-4 mb-6">
          <Field label="Nome completo" value={data.billing.name}
            onChange={v=>{upB('name',v);setErrs(e=>({...e,name:''}))}}
            placeholder="Seu nome completo" error={errs.name}/>
          <Field label="CPF" value={data.billing.cpf}
            onChange={v=>{upB('cpf',fmtCPF(v));setErrs(e=>({...e,cpf:''}))}}
            placeholder="000.000.000-00" error={errs.cpf}/>
          <Field label="E-mail para comprovante" type="email" value={data.billing.email}
            onChange={v=>{upB('email',v);setErrs(e=>({...e,email:''}))}}
            placeholder="seu@email.com" error={errs.email}/>
        </div>

        {/* Coupon */}
        <div className="mb-6">
          <p className="text-[13px] text-[#8e8e8e] mb-2">Cupom de desconto</p>
          {data.couponStatus === 'valid' ? (
            <div className="flex items-center justify-between bg-[#3ECF8E]/10 border border-[#3ECF8E]/30 rounded-[8px] px-3 py-2.5">
              <div className="flex items-center gap-2">
                <Tag size={13} className="text-[#3ECF8E]"/>
                <span className="text-[#3ECF8E] text-[13px] font-semibold">{data.couponCode}</span>
                <span className="text-[#3ECF8E] text-[12px]">— {(data.couponDiscount*100).toFixed(0)}% de desconto</span>
              </div>
              <button onClick={removeCoupon} className="text-[#8e8e8e] hover:text-white"><X size={14}/></button>
            </div>
          ) : (
            <>
              <div className="flex gap-2">
                <div className="flex-1">
                  <Field value={couponInput} onChange={setCouponInput} placeholder="Código do cupom"
                    error={data.couponStatus==='invalid'?'Cupom inválido ou expirado':undefined}/>
                </div>
                <button onClick={applyCoupon}
                  disabled={!couponInput.trim()||data.couponStatus==='loading'}
                  className="h-[48px] px-4 bg-[#2f2f2f] text-white text-[14px] rounded-[8px] hover:bg-[#3a3a3a] disabled:opacity-50 transition-colors self-start shrink-0">
                  {data.couponStatus==='loading'
                    ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"/>
                    : 'Aplicar'}
                </button>
              </div>
              <p className="text-[11px] text-[#3a3a3a] mt-1.5">Tente: PRAIA25 · AMIGO10 · BEACH50</p>
            </>
          )}
        </div>

        {/* Order Summary */}
        <p className="text-[13px] text-[#8e8e8e] mb-2">Resumo do pedido</p>
        <div className="bg-[#171717] rounded-[12px] border border-[#2a2a2a] overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#252525]">
                <th className="text-left text-[10px] text-[#4a4a4a] uppercase tracking-wider p-3 w-8">Qtd</th>
                <th className="text-left text-[10px] text-[#4a4a4a] uppercase tracking-wider p-3">Descrição</th>
                <th className="text-right text-[10px] text-[#4a4a4a] uppercase tracking-wider p-3">Valor</th>
              </tr>
            </thead>
            <tbody>
              {pricing.lines.map(({ cat, myPrice, partnerPrice, hasPartner, isDiscounted, payOption, userPays }) => {
                const qty = payOption === 'full' && hasPartner ? 2 : 1;
                return (
                  <tr key={cat.id} className="border-b border-[#222]">
                    <td className="p-3 text-[#8e8e8e] text-[12px]">{qty}</td>
                    <td className="p-3 text-white text-[12px]">
                      {cat.name} {cat.gender}
                      {isDiscounted && (
                        <span className="ml-1.5 text-[10px] bg-[#3ECF8E]/20 text-[#3ECF8E] px-1 py-0.5 rounded-full">
                          −50% (você)
                        </span>
                      )}
                      {payOption === 'mine' && hasPartner && (
                        <span className="ml-1 text-[#4a4a4a] text-[10px]">(sua parte)</span>
                      )}
                      {isDiscounted && qty === 2 && (
                        <p className="text-[10px] text-[#4a4a4a] mt-0.5">
                          Você {fmt(myPrice)} + Dupla {fmt(partnerPrice)}
                        </p>
                      )}
                    </td>
                    <td className="p-3 text-right text-white text-[12px]">{fmt(userPays)}</td>
                  </tr>
                );
              })}

              {/* Coupon */}
              {pricing.couponAmt > 0 && (
                <tr className="border-b border-[#222]">
                  <td colSpan={2} className="p-3 text-[#3ECF8E] text-[12px]">
                    <Tag size={11} className="inline mr-1"/>
                    Cupom {data.couponCode} (−{(data.couponDiscount*100).toFixed(0)}%)
                  </td>
                  <td className="p-3 text-right text-[#3ECF8E] text-[12px]">−{fmt(pricing.couponAmt)}</td>
                </tr>
              )}

              {/* Taxa de Serviço */}
              <tr className="border-b border-[#222]">
                <td colSpan={2} className="p-3 text-[#8e8e8e] text-[12px]">
                  Taxa de Serviço (3%)
                  <span className="ml-1 text-[10px] text-[#3a3a3a]">— plataforma</span>
                </td>
                <td className="p-3 text-right text-[#8e8e8e] text-[12px]">{fmt(pricing.serviceFee)}</td>
              </tr>

              {/* Total */}
              <tr>
                <td colSpan={2} className="p-3 text-white font-semibold text-[14px]">Total</td>
                <td className="p-3 text-right text-[#3ECF8E] font-semibold text-[17px]">{fmt(pricing.total)}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Partner charges summary */}
        {pricing.partnerTotalOwed > 0 && (
          <div className="mt-3">
            <InfoBox color="amber">
              As duplas com pagamento separado receberão e-mails individuais com suas respectivas faturas.
              Total cobrado às duplas:{' '}
              <span className="font-semibold text-white">{fmt(pricing.partnerTotalOwed)}</span>
              {' '}(+ taxa de serviço).
            </InfoBox>
          </div>
        )}
      </Card>
      <Nav onBack={onBack} onNext={() => { if (validate()) onNext(); }} nextLabel="Ir para pagamento"/>
    </>
  );
}

// ─── STEP 7: Payment Method ───────────────────────────────────────────────────
function PaymentMethodStep({ data, onUpdate, onNext, onBack }: {
  data: CheckoutData; onUpdate: (u: Partial<CheckoutData>) => void;
  onNext: () => void; onBack: () => void;
}) {
  const pricing = computePricing(data);
  return (
    <>
      <Card>
        <StepHeading title="Forma de pagamento"
          subtitle={`Total a pagar: ${fmt(pricing.total)}`}/>
        <div className="flex flex-col gap-3">
          {([
            { id:'pix' as const,         icon:<Smartphone size={20}/>, title:'Pix',              sub:'Aprovação imediata · QR Code ou Copia e Cola' },
            { id:'credit_card' as const, icon:<CreditCard size={20}/>, title:'Cartão de Crédito', sub:'Visa, Mastercard, Elo e outras bandeiras' },
          ] as const).map(m => {
            const sel = data.paymentMethod === m.id;
            return (
              <button key={m.id} onClick={() => onUpdate({ paymentMethod: m.id })}
                className={`w-full text-left p-4 rounded-[12px] border transition-all flex items-center gap-4
                  ${sel?'border-[#3ECF8E] bg-[#3ECF8E]/10 ring-1 ring-[#3ECF8E]/20':'border-[#2a2a2a] bg-[#171717] hover:border-[#4a4a4a]'}`}>
                <div className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 transition-all
                  ${sel?'bg-[#3ECF8E] text-[#121212]':'bg-[#252525] text-[#8e8e8e]'}`}>{m.icon}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-semibold">{m.title}</p>
                  <p className="text-[#8e8e8e] text-[12px]">{m.sub}</p>
                </div>
                {sel && (
                  <div className="w-5 h-5 bg-[#3ECF8E] rounded-full flex items-center justify-center shrink-0">
                    <Check size={11} className="text-[#121212]"/>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </Card>
      <Nav onBack={onBack} onNext={onNext} nextDisabled={!data.paymentMethod}/>
    </>
  );
}

// ─── STEP 8: Payment Details ──────────────────────────────────────────────────
function QRCode() {
  const N=21, cs=9;
  const pat = Array.from({length:N},(_,r)=>Array.from({length:N},(_,c)=>{
    if(r<7&&c<7){ if(r===0||r===6||c===0||c===6)return 1; return r>=2&&r<=4&&c>=2&&c<=4?1:0; }
    if(r<7&&c>=14){ const cc=c-14; if(r===0||r===6||cc===0||cc===6)return 1; return r>=2&&r<=4&&cc>=2&&cc<=4?1:0; }
    if(r>=14&&c<7){ const rr=r-14; if(rr===0||rr===6||c===0||c===6)return 1; return rr>=2&&rr<=4&&c>=2&&c<=4?1:0; }
    if(r===6||c===6)return (r+c)%2===0?1:0;
    return (r*13+c*7+(r^c)*3)%3===0?1:0;
  }));
  return (
    <div className="bg-white p-3 rounded-[12px] inline-block">
      <svg viewBox={`0 0 ${N*cs} ${N*cs}`} width={N*cs} height={N*cs}>
        {pat.flatMap((row,r)=>row.map((cell,c)=>
          cell ? <rect key={`${r}-${c}`} x={c*cs} y={r*cs} width={cs} height={cs} fill="#000"/> : null,
        ))}
      </svg>
    </div>
  );
}

function PixPayment({ onNext }: { onNext:()=>void }) {
  const [t,setT]           = useState(15*60);
  const [copied,setCopied] = useState(false);
  useEffect(() => {
    const id = setInterval(() => setT(x => x > 0 ? x-1 : 0), 1000);
    return () => clearInterval(id);
  }, []);
  const fmt2 = (s:number) => `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
  const copy = () => {
    navigator.clipboard.writeText(PIX_CODE).catch(()=>{});
    setCopied(true); setTimeout(() => setCopied(false), 2500);
  };
  return (
    <div className="flex flex-col items-center gap-5">
      <div className={`flex items-center gap-2 px-4 py-2 rounded-[100px] border
        ${t<60?'bg-[#e5534b]/10 border-[#e5534b]/30':'bg-[#171717] border-[#2a2a2a]'}`}>
        <Clock size={14} className={t<60?'text-[#e5534b]':'text-[#3ECF8E]'}/>
        <span className={`font-mono text-[15px] font-bold ${t<60?'text-[#e5534b]':'text-[#3ECF8E]'}`}>{fmt2(t)}</span>
        <span className="text-[#8e8e8e] text-[12px]">para expirar</span>
      </div>
      <QRCode/>
      <p className="text-[#8e8e8e] text-[13px] text-center leading-relaxed max-w-xs">
        Abra o app do seu banco, escolha <strong className="text-white">Pix</strong> e escaneie o QR Code.
      </p>
      <div className="w-full">
        <p className="text-[12px] text-[#8e8e8e] mb-2">Pix Copia e Cola</p>
        <div className="flex gap-2">
          <div className="flex-1 bg-[#1c1c1c] border border-[#3c3c3c] rounded-[8px] px-3 py-2.5 text-[11px] text-[#4a4a4a] overflow-hidden text-ellipsis whitespace-nowrap">
            {PIX_CODE.slice(0,55)}…
          </div>
          <button onClick={copy}
            className={`flex items-center gap-1.5 px-3 h-[44px] rounded-[8px] text-[13px] font-medium transition-all shrink-0
              ${copied?'bg-[#3ECF8E]/10 text-[#3ECF8E] border border-[#3ECF8E]/30':'bg-[#2f2f2f] text-white hover:bg-[#3a3a3a]'}`}>
            {copied?<><Check size={14}/>Copiado!</>:<><Copy size={14}/>Copiar</>}
          </button>
        </div>
      </div>
      {t === 0
        ? <p className="text-[#e5534b] text-[13px] text-center">Tempo expirado. Atualize a página para gerar novo código.</p>
        : <Btn onClick={onNext} fullWidth>Já realizei o pagamento</Btn>}
    </div>
  );
}

function CardPayment({ onNext }: { onNext:()=>void }) {
  const [card,setCard] = useState({number:'',holder:'',expiry:'',cvv:''});
  const [errs,setErrs] = useState<Record<string,string>>({});
  const brand = cardBrand(card.number);
  const validate = () => {
    const e: Record<string,string> = {};
    if (card.number.replace(/\s/g,'').length < 16) e.number = 'Número inválido';
    if (card.holder.trim().length < 3)             e.holder = 'Nome inválido';
    const m = card.expiry.match(/^(\d{2})\/(\d{2})$/);
    if (!m) { e.expiry = 'Formato inválido (MM/AA)'; }
    else {
      const mn=parseInt(m[1]), yr=2000+parseInt(m[2]), now=new Date();
      if (mn<1||mn>12) e.expiry = 'Mês inválido';
      else if (yr<now.getFullYear()||(yr===now.getFullYear()&&mn<now.getMonth()+1)) e.expiry = 'Cartão vencido';
    }
    if (card.cvv.length < 3) e.cvv = 'CVV inválido';
    setErrs(e);
    return !Object.keys(e).length;
  };
  return (
    <div className="flex flex-col gap-4">
      {/* Card visual */}
      <div className="relative bg-gradient-to-br from-[#2a2a2a] to-[#1a1a1a] rounded-[16px] p-6 border border-[#3c3c3c] overflow-hidden select-none">
        <div className="absolute -top-8 -right-8 w-32 h-32 bg-[#3ECF8E]/5 rounded-full"/>
        <div className="relative">
          <div className="flex justify-between items-start mb-8">
            <div className="w-11 h-8 bg-gradient-to-r from-[#FFD700] to-[#FFA500] rounded-[4px] opacity-90"/>
            {brand && <span className="text-[#8e8e8e] text-[13px] font-semibold">{brand}</span>}
          </div>
          <p className="text-white font-mono text-[18px] tracking-[0.2em] mb-4">{card.number||'•••• •••• •••• ••••'}</p>
          <div className="flex justify-between items-end">
            <div>
              <p className="text-[10px] text-[#4a4a4a] uppercase tracking-wider mb-0.5">Titular</p>
              <p className="text-white text-[13px] uppercase tracking-wide">{card.holder||'NOME TITULAR'}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-[#4a4a4a] uppercase tracking-wider mb-0.5">Validade</p>
              <p className="text-white text-[13px]">{card.expiry||'MM/AA'}</p>
            </div>
          </div>
        </div>
      </div>
      <Field label="Número do cartão" value={card.number}
        onChange={v=>{setCard(c=>({...c,number:fmtCard(v)}));setErrs(e=>({...e,number:''}))}}
        placeholder="0000 0000 0000 0000" error={errs.number}
        suffix={brand?<span className="text-[#8e8e8e] text-[12px]">{brand}</span>:undefined}/>
      <Field label="Nome no cartão" value={card.holder}
        onChange={v=>{setCard(c=>({...c,holder:v.toUpperCase()}));setErrs(e=>({...e,holder:''}))}}
        placeholder="NOME COMO ESTÁ NO CARTÃO" error={errs.holder}/>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Validade" value={card.expiry}
          onChange={v=>{setCard(c=>({...c,expiry:fmtExpiry(v)}));setErrs(e=>({...e,expiry:''}))}}
          placeholder="MM/AA" error={errs.expiry}/>
        <Field label="CVV" value={card.cvv}
          onChange={v=>{setCard(c=>({...c,cvv:v.replace(/\D/g,'').slice(0,4)}));setErrs(e=>({...e,cvv:''}))}}
          placeholder="•••" error={errs.cvv}/>
      </div>
      <Btn onClick={() => { if (validate()) onNext(); }} fullWidth>Finalizar pagamento</Btn>
    </div>
  );
}

function PaymentDetailsStep({ data, onNext, onBack }: {
  data: CheckoutData; onUpdate: (u: Partial<CheckoutData>) => void;
  onNext: () => void; onBack: () => void;
}) {
  const pricing = computePricing(data);
  const isPix   = data.paymentMethod === 'pix';
  return (
    <>
      <Card>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-white text-[22px] font-semibold">{isPix?'Pague via Pix':'Dados do cartão'}</h2>
            <p className="text-[#8e8e8e] text-[14px]">
              Total: <span className="text-[#3ECF8E] font-semibold">{fmt(pricing.total)}</span>
            </p>
          </div>
          <div className="w-11 h-11 rounded-full bg-[#3ECF8E]/20 flex items-center justify-center">
            {isPix
              ? <Smartphone size={18} className="text-[#3ECF8E]"/>
              : <CreditCard  size={18} className="text-[#3ECF8E]"/>}
          </div>
        </div>
        {isPix ? <PixPayment onNext={onNext}/> : <CardPayment onNext={onNext}/>}
      </Card>
      {!isPix && (
        <div className="mt-4 text-center">
          <button onClick={onBack}
            className="text-[#8e8e8e] text-[13px] hover:text-white flex items-center gap-1.5 mx-auto">
            <ArrowLeft size={14}/>Voltar para forma de pagamento
          </button>
        </div>
      )}
    </>
  );
}

// ─── STEP 9: Success ──────────────────────────────────────────────────────────
function SuccessStep({ data }: { data: CheckoutData }) {
  const navigate = useNavigate();
  const isPix    = data.paymentMethod === 'pix';
  const pricing  = computePricing(data);

  // Build per-partner email list for "mine" categories
  const partnerEmails = pricing.lines
    .filter(l => l.payOption === 'mine' && l.hasPartner)
    .map(l => ({
      partner: data.partners[l.cat.id]!,
      cat: l.cat,
      amount: l.partnerPrice,
    }));

  return (
    <div className="flex-1 flex items-center justify-center p-6">
      <div className="text-center max-w-md w-full">
        <div className="flex justify-center mb-8">
          <div className="w-28 h-28 bg-[#3ECF8E]/10 rounded-full flex items-center justify-center">
            <div className="w-20 h-20 bg-[#3ECF8E]/20 rounded-full flex items-center justify-center">
              <CheckCircle2 size={44} className="text-[#3ECF8E]" strokeWidth={1.5}/>
            </div>
          </div>
        </div>

        <h1 className="text-white text-[28px] font-semibold mb-3 leading-tight">
          {isPix ? 'Aguardando confirmação' : 'Inscrição confirmada! 🎉'}
        </h1>
        <p className="text-[#8e8e8e] text-[15px] leading-relaxed mb-2">
          {isPix
            ? 'Sua inscrição será confirmada assim que o Pix for processado (geralmente em minutos).'
            : 'Sua inscrição no Praia Cup está confirmada e já consta no sistema.'}
        </p>
        <p className="text-[#4a4a4a] text-[13px] mb-6">
          Comprovante enviado para{' '}
          <span className="text-white">{data.billing.email || data.user?.email}</span>
        </p>

        {/* Categories */}
        <div className="bg-[#1c1c1c] border border-[#2a2a2a] rounded-[12px] p-4 text-left mb-4">
          <p className="text-[11px] text-[#4a4a4a] uppercase tracking-wider mb-3">Categorias inscritas</p>
          {data.selectedCategories.map(cat => {
            const partner = data.partners[cat.id];
            return (
              <div key={cat.id} className="flex items-center justify-between py-2.5 border-b border-[#222] last:border-0">
                <div>
                  <p className="text-white text-[14px] font-medium">{cat.name} {cat.gender}</p>
                  {partner && <p className="text-[#8e8e8e] text-[12px]">Dupla: {partner.name}</p>}
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={13} className="text-[#3ECF8E]"/>
                  <span className="text-[#3ECF8E] text-[12px]">{isPix?'Aguardando':'Inscrito'}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Per-partner email notifications */}
        {partnerEmails.length > 0 && (
          <div className="bg-[#1c1c1c] border border-[#2a2a2a] rounded-[12px] p-4 text-left mb-6">
            <p className="text-[11px] text-[#4a4a4a] uppercase tracking-wider mb-3">
              E-mails enviados às duplas
            </p>
            {partnerEmails.map(({ partner, cat, amount }, i) => (
              <div key={i} className="flex items-start gap-3 py-2.5 border-b border-[#222] last:border-0">
                <Mail size={14} className="text-amber-400 mt-0.5 shrink-0"/>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-[13px] font-medium truncate">{partner.name}</p>
                  <p className="text-[#8e8e8e] text-[11px]">
                    {partner.precadastroEmail || `@${partner.nickname}`}
                    {' '}· {cat.name} {cat.gender}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-amber-400 font-semibold text-[13px]">{fmt(amount)}</p>
                  <p className="text-[#3a3a3a] text-[10px]">prazo: 3 dias</p>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3">
          <Btn variant="secondary" onClick={() => navigate('/')} fullWidth>
            <ArrowLeft size={15}/>Voltar ao evento
          </Btn>
          <Btn onClick={() => navigate('/')} fullWidth>
            <Award size={15}/>Ver painel do torneio
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ─── Main Checkout Page ───────────────────────────────────────────────────────
export function CheckoutPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState<CheckoutStep>('auth');
  const [data, setData] = useState<CheckoutData>(INITIAL_DATA);

  const update = (u: Partial<CheckoutData>) => setData(p => ({ ...p, ...u }));

  const goNext = () => {
    const i = STEP_ORDER.indexOf(step);
    if (i < STEP_ORDER.length - 1) setStep(STEP_ORDER[i + 1]);
  };
  const goBack = () => {
    const i = STEP_ORDER.indexOf(step);
    if (i > 0) setStep(STEP_ORDER[i - 1]); else navigate('/');
  };

  const stepProps = { data, onUpdate: update, onNext: goNext, onBack: goBack };

  return (
    <div className="min-h-screen bg-[#121212] flex flex-col" style={{ fontFamily:"'DM Sans',sans-serif" }}>

      {/* ── Banner — rola normalmente com a página ── */}
      <EventBanner/>

      {/* ── Nav + Steps — fixos no topo após o banner rolar ── */}
      <div className="sticky top-0 z-20">
        {/* Thin nav bar */}
        <div className="bg-[#121212]/95 backdrop-blur-sm border-b border-[#1a1a1a] flex items-center justify-between px-5 py-2.5">
          {step !== 'success'
            ? <button
                onClick={() => { if (STEP_ORDER.indexOf(step) > 0) goBack(); else navigate('/'); }}
                className="flex items-center gap-1.5 text-[#8e8e8e] hover:text-white transition-colors text-[13px]">
                <ArrowLeft size={15}/><span className="hidden sm:inline">Voltar</span>
              </button>
            : <div/>}
          <div className="flex items-center gap-2">
            <img src={imgSynergy} className="w-5 h-5 rounded-full object-cover" alt=""/>
            <span className="text-white text-[13px] font-semibold">Praia Cup</span>
            <span className="text-[#3a3a3a] text-[13px]">— Inscrição</span>
          </div>
          <div className="w-16"/>
        </div>

        {/* Step indicator */}
        {step !== 'success' && (
          <div className="bg-[#121212]/95 backdrop-blur-sm border-b border-[#1a1a1a]">
            <StepIndicator current={step}/>
          </div>
        )}
      </div>

      {/* ── Scrollable content ── */}
      <div className={`flex-1 ${step==='success'?'flex flex-col':''}`}>
        <div className={step==='success' ? 'flex-1 flex flex-col' : 'max-w-2xl mx-auto px-4 py-6 pb-12 w-full'}>
          {step === 'auth'            && <AuthStep onUpdate={update} onNext={goNext}/>}
          {step === 'categories'      && <CategoryStep {...stepProps}/>}
          {step === 'partners'        && <PartnerStep {...stepProps}/>}
          {step === 'uniforms'        && <UniformStep {...stepProps}/>}
          {step === 'review'          && <ReviewStep {...stepProps} onGoTo={setStep}/>}
          {step === 'billing'         && <BillingStep {...stepProps}/>}
          {step === 'payment-method'  && <PaymentMethodStep {...stepProps}/>}
          {step === 'payment-details' && <PaymentDetailsStep {...stepProps}/>}
          {step === 'success'         && <SuccessStep data={data}/>}
        </div>
      </div>
    </div>
  );
}
